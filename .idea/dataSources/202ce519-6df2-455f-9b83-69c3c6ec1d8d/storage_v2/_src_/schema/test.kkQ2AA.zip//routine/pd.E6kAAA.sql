create
    definer = root@localhost procedure pd()
begin
	insert into test1 values(null,'zhangsan',12,'男');
	insert into test1 values(null,'lisi',13,'男');
	insert into test1 values(null,'wangwu',14,'男');
	insert into test1 values(null,'zhaoliu',152,'男');
	insert into test1 values(null,'huangmazi',17,'男');
	insert into test1 values(null,'xionger',16,'男');
end;

