create
    definer = root@localhost procedure pd2(IN num int)
begin 
	while num<10 do
		select num;
		set num=num+1;
	end while;
end;

