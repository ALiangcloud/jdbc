create view vw as
select `test`.`test1`.`id`   AS `id`,
       `test`.`test1`.`name` AS `name`,
       `test`.`test1`.`age`  AS `age`,
       `test`.`test1`.`sex`  AS `sex`
from `test`.`test1`;

