create
    definer = root@localhost function fun() returns varchar(20)
begin
declare name1 varchar(20) default '无';
select name into name1
from test1
where id=11;
return name1;
end;

